package cadastrobd.model;

// Código da classe CadastroBDTeste
// (Conteúdo omitido para brevidade)