package cadastrobd.model;

// Código da classe PessoaJuridicaDAO
// (Conteúdo omitido para brevidade)