package cadastrobd.model;

// Código da classe PessoaJuridica
// (Conteúdo omitido para brevidade)