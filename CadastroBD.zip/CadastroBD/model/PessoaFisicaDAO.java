package cadastrobd.model;

// Código da classe PessoaFisicaDAO
// (Conteúdo omitido para brevidade)