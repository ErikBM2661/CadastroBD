package cadastrobd.model;

// Código da classe PessoaFisica
// (Conteúdo omitido para brevidade)