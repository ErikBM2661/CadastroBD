package cadastrobd.model.util;

// Código da classe ConectorBD
// (Conteúdo omitido para brevidade)