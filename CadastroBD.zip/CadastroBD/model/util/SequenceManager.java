package cadastrobd.model.util;

// Código da classe SequenceManager
// (Conteúdo omitido para brevidade)